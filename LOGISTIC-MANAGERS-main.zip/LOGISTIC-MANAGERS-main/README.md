# LOGISTIC-MANAGERS
Developed a team-based web application aimed at improving logistics by optimizing transportation methods. Focused on reducing overall shipment costs for goods and services through smart route planning and resource allocation. The project enhances efficiency and supports scalable supply chain systems.
